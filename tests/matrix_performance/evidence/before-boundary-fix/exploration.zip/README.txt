Exploratory matrix transpose variants, 2026-09-24.
These are screening results and focused diagnostics, not full-unit receipts.
The source-first, short-rows, short-novec, combined, pairs, packed-pairs and
vector-core variants were not promoted. The dual-core prototype improved all
measured nonempty C comparisons but regressed two rectangles versus old Ada.
The retained square-vector variant limits forced vectorization to medium
squares. A later final build/proof/timing package, outside this archive, governs
acceptance; exploratory ratios must not be substituted for final results.
The lanes prototype passed diagnostics but was not timed: disassembly did not
show the intended packed copy. Experimental binaries and full disassemblies
remain in the task workspace, not this archive.
Separate-executable samples showed C-reference shifts even with the same
normalized C instructions. The linked comparisons put both Ada variants and
one unchanged C implementation in the same executable. Read both the direct
Ada comparison and the C/C control; do not select only a favorable ratio.
Proof log filenames for individual subprograms reflect the latest diagnostic
using that name. Aggregate proof-<variant>.log files retain variant outcomes;
no rejected variant is assigned complete-unit Gold status.

The historical 451-case generator is preserved in historical/compare_matrices.py. The exploratory numeric runner added 40 cases. Live generator imports in those old scripts must use that historical snapshot to reproduce their original corpus.
