from pathlib import Path
import subprocess,sys,re
h=Path(__file__).resolve().parent
src=h/'candidate/src/mj-matrices.adb'
for name in sys.argv[1:]:
 lines=[i for i,s in enumerate(src.read_text().splitlines(),1) if re.match(r'   (function|procedure) '+re.escape(name)+r'\b',s)]
 assert len(lines)==1,(name,lines)
 with (h/('proof-'+name+'.log')).open('w') as out:
  r=subprocess.run([sys.executable,str(h/'run.py'),'candidate',sys.executable,'tools/guarded.py','--cap-mb','4000','--timeout','180','--','gnatprove','-P','proof.gpr','-u','mj-matrices.adb','--limit-subp=mj-matrices.adb:'+str(lines[0]),'--level=2','--proof=per_check','--timeout=10','-j2','--report=all','--checks-as-errors=on','--warnings=continue','--counterexamples=off'],stdout=out,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
