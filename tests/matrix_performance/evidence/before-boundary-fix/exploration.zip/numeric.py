from pathlib import Path
import importlib.util,subprocess,hashlib,json,sys
h=Path(__file__).resolve().parent
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
spec=importlib.util.spec_from_file_location('matrix_compare',repo/'tools/compare_matrices.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=m.cases()
for nr,nc in [(1,64),(8,64),(15,7),(16,7),(17,7),(15,16),(16,16),(17,16),(0,16),(16,0)]:
 nk=1
 for value in [0.0,-0.0,1e10,5e-324]:
  arrays=[[value if i%2 else -value for i in range(n)] for n in [nr*nc,nc*nk,nk*nc,nr*nk,nc,nr,nr]]
  rows.append((nr,nc,nk,*arrays,[nr-1,0,nr-1] if nr else []))
payload=m.serialize(rows)
probe=h/'candidate/build/checks-bin/matrix_probe'
proc=subprocess.run([str(probe)],input=payload,text=True,capture_output=True,timeout=90)
print(proc.stderr, file=sys.stderr)
proc.check_returncode()
actual=proc.stdout
out=[]
for mode in ['scalar','native_simd']:
 ref=h.parent/'matrices/upstream-3.14'/('matrix_reference_'+mode)
 expected=subprocess.run([str(ref)],input=payload,text=True,capture_output=True,check=True,timeout=90).stdout
 count=m.compare(rows,actual,expected)
 out.append(dict(reference=mode,cases=len(rows),comparisons=count,binary_sha256=hashlib.sha256(ref.read_bytes()).hexdigest()))
report=dict(results=out,ada_binary_sha256=hashlib.sha256(probe.read_bytes()).hexdigest(),matrix_source_sha256=hashlib.sha256((h/'candidate/src/mj-matrices.adb').read_bytes()).hexdigest())
(h/(sys.argv[1]+'-numeric.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(out))
