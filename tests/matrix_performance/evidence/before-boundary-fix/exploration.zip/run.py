from pathlib import Path
import os,subprocess,sys
h=Path(__file__).resolve().parent
root=Path('/var/tmp/sparkling-matrix-recovery/toolchains')
env=os.environ.copy()
env['PATH']=':'.join(str(next((root/x).glob('*/bin'))) for x in ('gnat','gprbuild','gnatprove'))+':'+env['PATH']
sys.exit(subprocess.call(sys.argv[2:],cwd=h/sys.argv[1],env=env))
