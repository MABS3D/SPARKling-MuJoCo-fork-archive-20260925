# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-urez07lh/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 127` | `mj-data-forces_phase.adb:127` | [tool_error](logs/mj-data-forces_phase__adb_line_127.log) | 0 | 0 | 0 | 27.1 |
| `line 131` | `mj-data-forces_phase.adb:131` | [tool_error](logs/mj-data-forces_phase__adb_line_131.log) | 0 | 0 | 0 | 3.4 |
| `line 156` | `mj-data-forces_phase.adb:156` | [tool_error](logs/mj-data-forces_phase__adb_line_156.log) | 0 | 0 | 0 | 3.4 |
| `line 161` | `mj-data-forces_phase.adb:161` | [tool_error](logs/mj-data-forces_phase__adb_line_161.log) | 0 | 0 | 0 | 3.4 |
| `line 186` | `mj-data-forces_phase.adb:186` | [tool_error](logs/mj-data-forces_phase__adb_line_186.log) | 0 | 0 | 0 | 2.6 |
| `line 203` | `mj-data-forces_phase.adb:203` | [tool_error](logs/mj-data-forces_phase__adb_line_203.log) | 0 | 0 | 0 | 2.9 |
| `line 223` | `mj-data-forces_phase.adb:223` | [tool_error](logs/mj-data-forces_phase__adb_line_223.log) | 0 | 0 | 0 | 2.4 |
| `line 231` | `mj-data-forces_phase.adb:231` | [tool_error](logs/mj-data-forces_phase__adb_line_231.log) | 0 | 0 | 0 | 2.9 |

## Diagnostics

