# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-1jyr5td_/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Allocate_Kinematic` | `mj-data.adb:397` | [completed_no_unproved](logs/mj-data__allocate_kinematic__adb_397.log) | 37 | 0 | 0 | 38.6 |
| `Clear_Kinematic` | `mj-data.adb:984` | [completed_no_unproved](logs/mj-data__clear_kinematic__adb_984.log) | 73 | 0 | 0 | 34.5 |
| `Free_Kinematic` | `mj-data.adb:895` | [completed_no_unproved](logs/mj-data__free_kinematic__adb_895.log) | 1 | 0 | 0 | 9.2 |

## Diagnostics

