# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-pz25kleu/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Fixed_Position` | `mj-data-pipeline.adb:57` | [unproved_checks](logs/mj-data-pipeline__fixed_position__adb_57.log) | 21 | 1 | 0 | 49.5 |

## Diagnostics

### mj-data-pipeline__fixed_position__adb_57

- `mj-data-pipeline.adb:82` (medium): assertion might fail [provers reached time limit before completing the proof]

