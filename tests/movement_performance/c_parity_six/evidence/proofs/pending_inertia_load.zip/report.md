# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-tkq7q35_/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:417` | [unproved_checks](logs/mj-data-inertia_phase__load_ancestor_factor__adb_417.log) | 23 | 3 | 0 | 83.5 |

## Diagnostics

### mj-data-inertia_phase__load_ancestor_factor__adb_417

- `mj-data-inertia_phase.adb:423` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:454` (medium): assertion might fail, cannot prove Storage_Ready (D) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:454` (medium): in inlined expression function body at mj-data.ads:629

