# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-xo0vvalg/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Dot_Blocks` | `mj-solver_reductions.adb:15` | [completed_no_unproved](logs/mj-solver_reductions__dot_blocks__adb_15.log) | 158 | 0 | 0 | 154.6 |
| `Dot_Four` | `mj-solver_reductions.adb:89` | [unproved_checks](logs/mj-solver_reductions__dot_four__adb_89.log) | 52 | 4 | 0 | 49.7 |

## Diagnostics

### mj-solver_reductions__dot_four__adb_89

- `mj-solver_reductions.adb:107` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-solver_reductions.adb:116` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-solver_reductions.adb:125` (medium): assertion might fail [provers reached time and memory limit before completing the proof]
- `mj-solver_reductions.ads:276` (medium): postcondition might fail, cannot prove Sum = Four_Sum (P, Row, Factor, Values) [provers reached time and memory limit before completing the proof]

