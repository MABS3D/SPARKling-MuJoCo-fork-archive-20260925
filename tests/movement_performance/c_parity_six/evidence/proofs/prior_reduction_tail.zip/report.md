# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-3bw00bj_/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Dot_Four` | `mj-solver_reductions.adb:89` | [unproved_checks](logs/mj-solver_reductions__dot_four__adb_89.log) | 53 | 3 | 0 | 44.1 |

## Diagnostics

### mj-solver_reductions__dot_four__adb_89

- `mj-solver_reductions.adb:122` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-solver_reductions.adb:131` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-solver_reductions.ads:285` (medium): postcondition might fail, cannot prove Sum = Four_Sum (P, Row, Factor, Values) [provers reached time limit before completing the proof]

