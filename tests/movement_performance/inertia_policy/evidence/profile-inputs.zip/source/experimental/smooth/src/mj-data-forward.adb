with Movement_Profile; use Movement_Profile;
with MJ.Data.Kinematics;
with MJ.Data.Inertia;
with MJ.Data.Forces;
with MJ.Data.Actuation;

package body MJ.Data.Forward with SPARK_Mode is
   procedure Evaluate (D : in out Simulation; Result : out Status) is
      --  Compose phase contracts without expanding their representation.
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Is_Ready);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Is_Empty);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", State_Values);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Input_Values);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Shape);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Positions_Current);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Forces_Current);
      Initial_State : constant Real_Array := State_Values (D) with Ghost => Static;
      Initial_Inputs : constant Real_Array := Input_Values (D) with Ghost => Static;
   begin
      Movement_Profile.Start (Movement_Profile.Kinematics);
      Kinematics.Update (D, Result);
      Movement_Profile.Stop (Movement_Profile.Kinematics);
      pragma Assert (Static => State_Values (D) = Initial_State);
      pragma Assert (Static => Input_Values (D) = Initial_Inputs);
      if Result /= Success then
         return;
      end if;
      Movement_Profile.Start (Movement_Profile.Mass);
      Inertia.Assemble (D, Result);
      Movement_Profile.Stop (Movement_Profile.Mass);
      pragma Assert (Static => State_Values (D) = Initial_State);
      pragma Assert (Static => Input_Values (D) = Initial_Inputs);
      if Result /= Success then
         return;
      end if;
      Movement_Profile.Start (Movement_Profile.Forces);
      Forces.Compute (D, Result);
      Movement_Profile.Stop (Movement_Profile.Forces);
      pragma Assert (Static => State_Values (D) = Initial_State);
      pragma Assert (Static => Input_Values (D) = Initial_Inputs);
      if Result /= Success then
         return;
      end if;
      Movement_Profile.Start (Movement_Profile.Actuation);
      Actuation.Compute (D, Result);
      Movement_Profile.Stop (Movement_Profile.Actuation);
      pragma Assert (Static => State_Values (D) = Initial_State);
      pragma Assert (Static => Input_Values (D) = Initial_Inputs);
      if Result /= Success then
         return;
      end if;
      Movement_Profile.Start (Movement_Profile.Acceleration);
      Inertia.Solve_Acceleration (D, Result);
      Movement_Profile.Stop (Movement_Profile.Acceleration);
      pragma Assert (Static => State_Values (D) = Initial_State);
      pragma Assert (Static => Input_Values (D) = Initial_Inputs);
   end Evaluate;
end MJ.Data.Forward;
