package body MJ.Bounds_Kernels with SPARK_Mode is
   function All_Within (Values : Real_Array; Limit : Real) return Boolean is
      Accepted : Boolean := True;
   begin
      for I in Values'Range loop
         Accepted := Accepted and (Values (I) in -Limit .. Limit);
         pragma Loop_Invariant
           (Static => Accepted = (for all J in Values'First .. I =>
              Values (J) in -Limit .. Limit));
      end loop;
      return Accepted;
   end All_Within;
end MJ.Bounds_Kernels;
